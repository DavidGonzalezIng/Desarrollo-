const clueCards = [...document.querySelectorAll('.clue-card')];
const suspects = [...document.querySelectorAll('.suspect')];
const clueCount = document.getElementById('clueCount');
const attemptsText = document.getElementById('attempts');
const feedback = document.getElementById('feedback');
const solveBtn = document.getElementById('solveBtn');
const resetBtn = document.getElementById('resetBtn');
let selectedSuspect = null;
let attempts = 0;
let solved = false;

function updateClueCount() {
  const opened = clueCards.filter(card => card.classList.contains('open')).length;
  clueCount.textContent = `${opened}/3`;
}

clueCards.forEach(card => {
  card.addEventListener('click', () => {
    card.classList.toggle('open');
    updateClueCount();
  });
});

suspects.forEach(button => {
  button.addEventListener('click', () => {
    if (solved) return;
    suspects.forEach(item => item.classList.remove('selected'));
    button.classList.add('selected');
    selectedSuspect = button.dataset.suspect;
    solveBtn.disabled = false;
    feedback.className = 'feedback';
    feedback.textContent = `Has señalado a ${selectedSuspect}. ¿Tus pistas respaldan esa acusación?`;
  });
});

solveBtn.addEventListener('click', () => {
  if (!selectedSuspect || solved) return;
  attempts++;
  attemptsText.textContent = attempts;
  if (selectedSuspect === 'Luna') {
    solved = true;
    feedback.className = 'feedback success';
    feedback.textContent = '🎉 ¡Caso resuelto! Luna mintió al decir que no entró a la cocina. Las huellas con harina la relacionan con el plato y Milo la vio salir. ¡Buen trabajo, detective!';
    solveBtn.textContent = '¡Misterio resuelto!';
    solveBtn.disabled = true;
    suspects.forEach(item => item.disabled = true);
  } else {
    feedback.className = 'feedback error';
    feedback.textContent = '❌ Esa acusación no encaja con todas las pistas. Vuelve a revisarlas y conecta las declaraciones con las huellas.';
  }
});

resetBtn.addEventListener('click', () => {
  selectedSuspect = null;
  attempts = 0;
  solved = false;
  clueCards.forEach(card => card.classList.remove('open'));
  suspects.forEach(item => { item.classList.remove('selected'); item.disabled = false; });
  clueCount.textContent = '0/3';
  attemptsText.textContent = '0';
  feedback.className = 'feedback';
  feedback.textContent = '🔎 Revisa las pistas y elige a un sospechoso.';
  solveBtn.textContent = 'Confirmar acusación';
  solveBtn.disabled = true;
});
